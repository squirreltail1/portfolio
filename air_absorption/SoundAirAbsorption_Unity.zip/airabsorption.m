%%
% SMC7 Signal Processing - Simulating Sound Propagation - ISO 9613-1  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
% Air Absorption - code partially taken from Edward L. Zechmann %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [atm, alpha_iso] = airabsorption(temperature, relative_humidity, pressure, distance)
if temperature >= -20 & temperature <= 50
    temp = temperature ; % temperature in celsius between -20-40º
else
    disp("Error: Temperature between -20 and 50")
end
if relative_humidity >= 1 & relative_humidity <= 100
    hr = relative_humidity; % humidity in percentage between 10-100%
else
    disp("Error: relative_humidity between 1-100");
end
if pressure == 1
    ps = pressure; % actual atmospheric pressure
else
    disp("Error: pressure has to be 1")
end

% Frequency range (in Hz)
% Frequency selection - fractional octave - for analysis only
%b_band = 1/3; % Band spacing factor (1 for octave bands)
%base_freq = 1000; % Reference frequency in Hz
%k_values = -13:16; % Range of k values to compute


% Precompute the multiplier
%multiplier = 10^(3 * b_band / 10);

% Calculate mid-band frequencies
%f_mid = base_freq * (multiplier.^k_values);
%frequencies = f_mid;
sample_rate=48000;
frequencies = 50:sample_rate/2;
d = distance;



t=273.15+temp; % convert to Kelvin
t01 = 273.16; %triple-point temperature
t0 = 293.15;

% pressure 
ps0 = 1; % standard atmospheric pressure at sea level in Pascal unity

% Iso formula for saturation pressure ratio
psat_ps0_iso=10^( -6.8346*(t01/t)^1.261+4.6151);

ps_ps0=ps/ps0;

h_iso = hr*psat_ps0_iso/ps_ps0; % humidity in percent molar concentration

c0 = 331; % c0 is the reference sound speed
c_iso = (1+0.16*h_iso/100)*c0*sqrt(t/t01); % speed of sound in humid air

% ISO formula

taur=t/t0;
pr=ps/ps0;

fr0 = pr * (24 + 40400 * h_iso * (0.02 + h_iso) / (0.391 + h_iso)); % Oxygen frequency
frN = pr * (taur)^(-1 / 2) * (9 + 280 * h_iso * exp(-4.17 * ((taur)^(-1 / 3) - 1))); % Nitrogen frequency

plot1 = figure;
hold on;
for j = 1:length(d)
    alpha_iso = zeros(size(frequencies));
    for n = 1:length(frequencies)
        f = frequencies(n);
        b1 = 0.1068 * exp(-3352 / t) / (frN + f^2 / frN);
        b2 = 0.01275 * exp(-2239.1 / t) / (fr0 + f^2 / fr0);

        % Calculate the air absorption in dB/meter using the ISO standard formula
        alpha_iso(n) = 8.686 * f^2 * taur^(1 / 2) * (1.84 * 10^(-11) / pr + taur^(-3) * (b1 + b2));
    end

    atm = alpha_iso * d(j);
    flipped = -atm;
    semilogx(frequencies, flipped,':', 'LineWidth', 2, 'DisplayName', sprintf('Distance = %d m', d(j)));
end

% Set the x-axis to log scale
title("0º, 100H")
set(gca, 'XScale', 'log');
xlabel('Frequency (Hz)');
ylabel('Attenuation (dB)');
yticks([-120 -100 -80 -60 -40 -20 0]);
ylim([-120 0]);
grid on;
legend('show');
xlim([50 sample_rate/2]); 
xticks([1e1/2 1e2 1e3 1e4]); 
%xticklabels({'50','100', '1k', '10k'});
% End the plotting with 'hold off'
hold off;