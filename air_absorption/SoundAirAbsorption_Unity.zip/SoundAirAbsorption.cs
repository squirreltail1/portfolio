using UnityEngine;
using System;
using AForge.Math;




[RequireComponent(typeof(AudioSource))]
public class SoundAirAbsorption : MonoBehaviour
{

    public GameObject AudioListener;

    [Range(0, 50)]
    public float Temperature = 20f;
    [Range(0, 100)]
    public float Humidity = 50f;
    [Range(0, 2)]
    public float Pressure = 1f;

    AirAbsorbFilter air_filter;
    const float update_rate = 0.05f;
    const int filter_length = 2048;


    public class AirModel
    {

        double Fr_O; //relaxation frequency of oxygen
        double Fr_N; //relaxation frequency of nitrogen

        const float T0 = 293.15f;
        const float T01 = 273.16f;

        float T;
        public float Temperature
        {
            get { return T; }
            set
            {
                if ((value >= 0) && (value <= 330))
                {
                    T = value;
                    updateRelaxFs();
                }
            }
        }

        float hr;
        public float Humidity
        {
            get { return hr; }
            set
            {
                if ((value >= 0) && (value <= 100))
                {
                    hr = value;
                    updateRelaxFs();
                }
            }
        }

        float ps;
        public float Pressure
        {
            get { return ps; }
            set
            {
                if ((value >= 0) && (value <= 2))
                {
                    ps = value;
                    updateRelaxFs();
                }
            }
        }

        public AirModel(float temp_kelvin, float h_relative, float atm_pressure = 1f)
        {
            T = temp_kelvin;
            hr = h_relative;
            ps = atm_pressure;
            updateRelaxFs();
        }

        public double getAbsCoeff(float f)
        {
            float F = f / ps;
            return 20 / Math.Log(10) * F * F * (1.84 * Math.Pow(10, -11) * Math.Sqrt(T / T0) +
                Math.Pow(T / T0, -2.5) * (0.01278 * Math.Exp(-2239.1 / T) / (Fr_O + F * F / Fr_O) + 0.1068 * Math.Exp(-3352 / T) / (Fr_N + F * F / Fr_N))) * ps;
        }

        void updateRelaxFs()
        {
            double h = hr * Math.Pow(10, -6.8346 * Math.Pow(T01 / T, 1.261) + 4.6151) / ps;
            Fr_O = 24 + 40400 * h * (0.02 + h) / (0.391 + h) / ps;
            Fr_N = Math.Sqrt(T0 / T) * (9 + 280 * h * Math.Exp(-4.17 * (Math.Pow(T0 / T, 1f / 3) - 1))) / ps;
        }
    }

    public AirModel airModel { get; private set; }


    class AirAbsorbFilter
    {
        public readonly AirModel m_AirModel;
        public Complex[] m_ImpulseResponse;
        int m_SamplingRate;
        // two channels - stereo 
        float[][] m_buffers = new float[2][];

        public AirAbsorbFilter(int sampling_rate)
        {
            m_SamplingRate = sampling_rate;
            m_AirModel = new AirModel(293.15f, 50);
            for (int i = 0; i < m_buffers.Length; ++i)
                m_buffers[i] = new float[0];
        }
        public void updateImpulseResponse(float distance, int N)
        {
            // design filter based on distance and current atmospheric properties
            // 'Frequency sampling' method

            Complex[] H = new Complex[N];
            float df = m_SamplingRate / N;

            // sample in (0,fs/2) range
            for (int i = 0; i < H.Length / 2 + 1; ++i)
            {
                float a = (float)m_AirModel.getAbsCoeff(df * i);
                H[i].Re = Mathf.Pow(10, -a * distance / 20);
            }

            //mirror DFT with respect to N/2+1 sample
            for (int i = H.Length / 2 + 1; i < H.Length; ++i)
                H[i] = H[N - i];

            //do IFFT to get impulse response
            FourierTransform.FFT(H, FourierTransform.Direction.Backward);

            //Aforge's FFT/IFFT is not normalized, divide by N
            for (int i = 0; i < H.Length; ++i)
                H[i] /= N;

            //impulse response
            m_ImpulseResponse = H;
            //shift by N/2
            Util.shiftArray<Complex>(m_ImpulseResponse, N / 2);

            //blackman window
            float[] blackman = Util.blackmanWindow(m_ImpulseResponse.Length);
            for (int i = 0; i < m_ImpulseResponse.Length; ++i)
                m_ImpulseResponse[i] *= blackman[i];

        }

        public void filter(float[] data, int num_ch)
        {
            //deinterleave data for filtering
            float[][] channels = Util.deinterleaveData<float>(data, num_ch);
            //filter every channel
            for (int ch = 0; ch < channels.Length; ++ch)
                filterChannel(channels[ch], ch);
            //interleave and copy back
            Util.interleaveData<float>(channels, data);
        }



        void filterChannel(float[] data, int channel)
        {
            //convolution using OVERLAP-ADD

            // get length that arrays will be zero-padded to
            int K = Mathf.NextPowerOfTwo(data.Length + m_ImpulseResponse.Length - 1);

            //create temporary (zero padded to K) arrays
            Complex[] ir_pad = new Complex[K];
            System.Array.Copy(m_ImpulseResponse, ir_pad, m_ImpulseResponse.Length);
            Complex[] data_pad = new Complex[K];
            for (int i = 0; i < data.Length; ++i)
                data_pad[i].Re = data[i];

            //FFT 
            FourierTransform.FFT(data_pad, FourierTransform.Direction.Forward);
            FourierTransform.FFT(ir_pad, FourierTransform.Direction.Forward);
            //convolution
            Complex[] ifft = new Complex[K];
            for (int i = 0; i < ifft.Length; ++i)
                ifft[i] = data_pad[i] * ir_pad[i] * K;
            FourierTransform.FFT(ifft, FourierTransform.Direction.Backward);
            //add from buffer 
            for (int i = 0; i < data.Length; ++i)
            {
                data[i] = (float)ifft[i].Re;
                if (i < m_buffers[channel].Length)
                    data[i] += m_buffers[channel][i];
            }
            //buffer last (K - data.length) samples
            m_buffers[channel] = new float[K - data.Length];
            for (int i = 0; i < m_buffers[channel].Length; ++i)
                m_buffers[channel][i] = (float)ifft[i + data.Length].Re;
        }

    }
    class Util
    {
        public static void shiftArray<T>(T[] array, int N)
        {
            T[] temp = new T[array.Length];
            System.Array.Copy(array, temp, array.Length);
            for (int i = 0; i < array.Length; ++i)
                array[(i + N) % array.Length] = temp[i];
        }

        public static float[] blackmanWindow(int N)
        {

            int M = (N % 2 == 0) ? N / 2 : (N + 1) / 2;

            float[] win = new float[N];
            win[0] = win[N - 1] = 0f;
            for (int i = 1; i < M; ++i)
                win[i] = win[N - 1 - i] = 0.42f - 0.5f * Mathf.Cos(2 * Mathf.PI * i / (N - 1)) + 0.08f * Mathf.Cos(4 * Mathf.PI * i / (N - 1));

            return win;
        }
        public static T[][] deinterleaveData<T>(T[] data, int num_ch)
        {
            T[][] deinterleaved = new T[num_ch][];
            int channel_length = data.Length / num_ch;
            for (int ch = 0; ch < num_ch; ++ch)
            {
                deinterleaved[ch] = new T[channel_length];
                for (int i = 0; i < channel_length; ++i)
                    deinterleaved[ch][i] = data[i * num_ch];
            }

            return deinterleaved;
        }

        public static void interleaveData<T>(T[][] data_in, T[] data_out)
        {
            int num_ch = data_in.Length;
            for (int i = 0; i < data_in[0].Length; ++i)
            {
                for (int ch = 0; ch < num_ch; ++ch)
                    data_out[i * num_ch + ch] = data_in[ch][i];
            }
        }
    }

    void Start()
    {
        air_filter = new AirAbsorbFilter(GetComponent<AudioSource>().clip.frequency);
        InvokeRepeating("updateFilter", 0, update_rate);
    }

    void Update()
    {

    }

    void OnAudioFilterRead(float[] data, int channels)
    {
        if (!ReferenceEquals(air_filter, null))
            air_filter.filter(data, channels);
    }

    void updateFilter()
    {
        float distance_to_source = UnityEngine.Vector3.Distance(AudioListener.transform.position, transform.position);
        air_filter.m_AirModel.Temperature = Temperature + 273.15f; //Celcius to Kelvin
        air_filter.m_AirModel.Humidity = Humidity;
        air_filter.m_AirModel.Pressure = Pressure;
        air_filter.updateImpulseResponse(distance_to_source, filter_length);
    }


}