% Read the audio file
[y, fs] = audioread('modified_recording.wav');

% Get the number of samples and use only one channel if stereo
y1 = y(1:24000,1);  
N = length(y1);                
%audiowrite('modified_recording.wav', y1, fs);  

% Perform FFT
ydft = fft(y1);              

% Only take first half of spectrum
ydft = ydft(1:floor(N/2)+1);

% Frequency vector (use linspace instead of colon operator)
freq = linspace(0, fs/2, floor(N/2)+1);

% Calculate magnitude in dB
magnitude_db = 20*log10(abs(ydft) / max(abs(ydft)));

% Calculate magnitude as percentage of the maximum value
magnitude_percent = 100 * abs(ydft) / max(abs(ydft));

% Plot magnitude in dB
plot(freq, magnitude_db);
set(gca, 'XScale', 'log');
title("Magnitude Response (dB)");
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
xlim([50 fs/2]); 
xticks([1e1/2 1e2 1e3 1e4]); 


% Plot magnitude as percentage of the maximum value
%subplot(2,1,2);
%plot(freq, magnitude_percent);
%title("Magnitude Response (Percentage)");
%xlabel('Frequency (Hz)');
%ylabel('Magnitude (%)');

% Optional: Plot phase
% subplot(2,1,2);
% plot(freq, unwrap(angle(ydft)));
% xlabel('Frequency (Hz)');
% ylabel('Phase (radians)');